from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

root = Path(__file__).resolve().parent
directory = root / "dist" if (root / "dist" / "index.html").exists() else root
handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
server = ThreadingHTTPServer(("127.0.0.1", 8765), handler)
url = "http://localhost:8765/"
print(f"HABRO ADB: {url}\nAbre este enlace en Chrome o Edge. Pulsa Ctrl+C para cerrar.")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
