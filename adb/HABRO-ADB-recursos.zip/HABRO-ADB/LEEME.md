# HABRO ADB

Conecta el sistema Android del coche por USB desde Chrome o Edge en un ordenador.
El coche debe tener ADB activo y autorizar la huella RSA. El puerto debe funcionar
como interfaz de datos ADB, no únicamente cargar o leer memorias USB.

## Abrir el paquete

Descomprime esta carpeta y ejecuta `python iniciar.py` o `py -3 iniciar.py` en
Windows. Necesita Python 3. El servidor escucha solo en 127.0.0.1 y abre
http://localhost:8765/. También puedes alojar estos recursos en HTTPS. No abras
el HTML directamente con file://. No necesita npm para utilizarse.

## Herramientas

- Conexión USB ADB y claves RSA conservadas localmente en el navegador.
- Aplicaciones: listar, instalar APK individuales, grupos independientes o
  splits, exportar APK, abrir y gestionar aplicaciones para el usuario activo.
- Consola, registros descargables, archivos, capturas y pantalla con scrcpy.
- Calculadora VIN + RAND (codigo.html), independiente de la clave diaria OTA.
- Calculadora OTA (ota.html): primero toma los últimos seis caracteres del VIN,
  extrae las cifras de ese fragmento (vacío equivale a cero), suma 123456,
  multiplica por la fecha yyMMdd y conserva seis cifras, con ceros iniciales.
  Valida los datos en vez de presentar un código de fallback.
- Asistente de instalación (#installer), con selección y comprobación local
  de APK/XAPK, método estándar o auxiliar SOP6/SOP7, progreso y diagnóstico.

## Método SOP6 / SOP7

Requiere una ROM identificada como SOP6 o SOP7, una sesión shell uid 2000 y el
usuario Android 0 activo. Se comprueba la identidad real de cada APK, el hash
SHA-256 del DEX, los tamaños transferidos, la salida completa y el paquete,
versión y partes que devuelve Android. Una versión inferior a la instalada se
rechaza. No se desinstala automáticamente una app para resolver conflictos de
firma ni se cambian políticas del dispositivo.

XAPK: una app con base, splits y OBB opcionales. Se valida el contenedor antes
de transferirlo. Máximo 1 GiB de archivo y de contenido descomprimido, 4096
entradas y 256 MiB por APK interior deflated. Se rechazan ZIP64, cifrado y
compresión no admitida. Los OBB pueden sustituir datos de esa app; se informa
si alguno no se copia. Cierra otros instaladores mientras utilizas el asistente.

El DEX utiliza una carpeta fija para extraer XAPK. La web rechaza una carpeta
preexistente y enlaces simbólicos; no borra esa carpeta compartida a ciegas.
Consulta vendor/SESSIONWRITER-NOTICE.txt para procedencia, hash y detalles.

Durante la preparación puedes cancelar. Una vez iniciado el auxiliar, HABRO
espera la respuesta de Android. Una desconexión o timeout no significa rollback.
El panel de intento pendiente identifica el paquete y permite comprobarlo al
reconectar el mismo coche. Cerrar el seguimiento no cancela Android. La
comprobación posterior verifica APK/partes, pero no los OBB. Los temporales de
un proceso incierto se conservan hasta que pueda aclararse su estado.

## Menú OTA

La apertura opcional de EngineModeActivity necesita ADB ya conectado. La ruta
manual para acceder por primera vez al menú sigue sin estar confirmada en el
kit. El código debe corresponder a la fecha que muestra el coche. No se promete
activar la primera conexión ADB desde un navegador sin acceso al dispositivo.

## Datos y validación

El VIN y los archivos no se envían a servidores. La transferencia se realiza
por USB. Los registros se conservan en la pestaña y se descargan solo a petición.
No se limpia el buffer logcat del coche para hacer un diagnóstico.

Se han comprobado el código, la interfaz y el protocolo con transporte simulado.
La compatibilidad física de esta integración con un coche está pendiente de
prueba. El kit Hermes informa de un ensayo SOP7 de su autor; no es una prueba
realizada por esta web. Android verifica las firmas y aplica sus permisos.

## Dependencias y procedencia

Tango ADB: https://github.com/yume-chan/ya-webadb
scrcpy: https://github.com/Genymobile/scrcpy
Licencias y versiones: vendor/THIRD_PARTY_NOTICES.txt y avisos de cada recurso.
SessionWriter: kit Hermes 2026-10-25, atribuido a japp.cloud / BK.
WebUSB: https://developer.chrome.com/docs/capabilities/usb
Android ADB: https://developer.android.com/tools/adb

Sitio: https://habroremote.com/adb/
Repositorio de despliegue: https://github.com/noquierotuemail-cell/ebro-horizon-assets
Las pruebas del repositorio se ejecutan con `node --test tests/*.test.mjs`.
