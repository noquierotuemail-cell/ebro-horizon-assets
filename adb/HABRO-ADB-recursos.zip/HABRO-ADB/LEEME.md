# HABRO ADB

Herramienta web para conectar por USB con el sistema Android del coche. Interfaz propia con el logo horizontal y los tokens visuales de HABRO; motor Tango ADB con versiones fijadas. No requiere Home Assistant y no modifica el APK existente de HABRO.

## Abrir

Usar el enlace HTTPS publicado en Chrome o Edge de escritorio. Pulsar **Conectar coche**, seleccionar el Android y aceptar la autorización RSA en la pantalla del coche. El puerto del coche debe exponer la interfaz ADB y la depuración USB debe estar activa.

El paquete descargable contiene el HTML, CSS, JavaScript, marca, licencias y servidor de pantalla. Para abrirlo localmente, descomprimir y ejecutar `python iniciar.py` o `py -3 iniciar.py` en Windows, con Python 3 instalado. El servidor solo escucha en la interfaz local del ordenador y abre `http://localhost:8765/`. No se necesita npm para usar el paquete. No abrir directamente el HTML con `file://`.

## Funciones

- Selección USB, autenticación RSA mediante la autorización nativa de Android, claves locales y desconexión.
- Identificación real del sistema, almacenamiento y usuario Android activo.
- Lista y filtros de aplicaciones; abrir, activar, desactivar, detener, borrar datos y desinstalar para el usuario activo. Los permisos especiales se gestionan abriendo los ajustes de Android.
- Instalación de APK individuales o splits mediante sesiones del Package Manager.
- Exportación de APK base y splits, manifiesto de resultados, guardado en carpeta o ZIP limitado por memoria. No constituye una copia de los datos privados de las aplicaciones.
- Consola, comandos rápidos, historial de sesión, detener, logcat y descarga del texto visible.
- Capturas PNG y scrcpy en directo con toques, gestos y teclas. El servidor scrcpy se comprueba por SHA-256 antes de enviarlo a `/data/local/tmp/habro-scrcpy-3.3.3.jar`.
- Exploración de carpetas, envío y descarga de archivos mediante ADB sync.
- Interfaz responsive con temas claro y oscuro.
- Generador local de código ADB v3 (VIN + RAND), accesible desde Inicio y `codigo.html`, también sin WebUSB. Calcula el código para introducirlo manualmente en el coche; no mantiene ADB abierto. Sus recursos se incluyen en la descarga.

## Límites comprobables

No hay una conexión física disponible desde el entorno de desarrollo. La prueba con el EBRO concreto sigue pendiente; los controles incluidos ejecutan ADB real, pero no se afirma compatibilidad física ya probada. La presencia de ADB, el puerto correcto, el controlador de Windows y los permisos dependen del ordenador y del firmware del coche. El generador v3 reproduce el cálculo del código; su aceptación por el coche sigue pendiente. No activa automáticamente ADB ni omite la autorización Android.

WebUSB requiere contexto seguro y navegador compatible. Safari/iPhone no ofrecen esta conexión. El vídeo depende de WebCodecs y de que Android permita la captura. No se transporta audio. No se proporciona conexión Wi-Fi/TCP directa: la conexión implementada es USB.

La exportación en memoria se limita a 256 MiB. Para archivos grandes, utilizar la escritura directa a disco que ofrecen navegadores compatibles. La consola mantiene la salida visible acotada; no equivale a un archivo logcat ilimitado. Se puede cancelar entre operaciones, pero una instalación ya enviada a Android espera la respuesta del Package Manager antes de limpiar sus archivos temporales.

## Fuentes y dependencias

- Diseño HABRO: `noquierotuemail-cell/ebro-remotepro-ha`, commit `5a1b4a0ced3fca510cbb2786a297512164a51945`, tokens de `index.html` y `assets/habro-remoteapp-horizontal-v8641.svg`.
- Referencia de funciones: https://jcartools.ru/adbtools/#dashboard. No se reutiliza su motor ofuscado.
- Tango ADB: https://github.com/yume-chan/ya-webadb — MIT. Versiones e integridades exactas en `package-lock.json` del código fuente.
- scrcpy: https://github.com/Genymobile/scrcpy/releases/tag/v3.3.3 — Apache-2.0.
- Servidor scrcpy SHA-256: `7e70323ba7f259649dd4acce97ac4fefbae8102b2c6d91e2e7be613fd5354be0`.
- Lucide y fflate: licencias incluidas en `vendor/THIRD_PARTY_NOTICES.txt`.
- Requisitos de USB: https://developer.chrome.com/docs/capabilities/usb y https://developer.mozilla.org/en-US/docs/Web/API/WebUSB_API.
- Autorización Android: https://developer.android.com/tools/adb.
- Generador v3: algoritmo observado en https://jcartools.ru/instr/en_ss.js e implementación independiente de https://www.rfc-editor.org/rfc/rfc4493.txt. Especificación y evidencias en `docs/adb-code-generator.md` del repositorio.

Los datos del coche permanecen en el navegador. No hay telemetría, servicios remotos ADB, CDN ni descarga de código de JCarTools durante la conexión.

## Desarrollo

En el repositorio de código: `npm ci --ignore-scripts`, `npm run build`, `npm test` y `node scripts/portable.mjs`. Se incluyen pruebas del tratamiento de comandos con el decodificador de protocolo real de Tango sobre un transporte simulado. No sustituyen la prueba física ni una prueba visual en navegador.
